﻿using FootBallTeamGenerator.Core;
using System;
using System.Runtime.CompilerServices;

namespace FootBallTeamGenerator
{
   public  class Program
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
