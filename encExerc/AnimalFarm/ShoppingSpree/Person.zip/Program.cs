﻿using ShoppingSpree.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ShoppingSpree
{
   public class Program
    {
        static void Main(string[] args)
        {

            Engine engine = new Engine();
            engine.Run();
           

           
            
        }
    }
}
