﻿using Raiding.Contracts;
using Raiding.Contracts.Core;
using Raiding.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Raiding
{
    public class Program
    {
        static void Main(string[] args)
        {

            IEngine engine = new Engine();

            engine.Run();

            

      





        }
    }
}
