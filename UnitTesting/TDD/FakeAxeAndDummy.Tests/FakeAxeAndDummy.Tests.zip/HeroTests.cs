﻿
using NUnit.Framework;


[TestFixture]
public class HeroTests
{
    [Test]
    public void HeroShouldGainExpWhenKillsTarget()
    {
       

        var fakeWeapon = new FakeWeapon();
        var fakeTarget = new FakeTarget();



        Hero hero = new Hero("Pesho", fakeWeapon);

        hero.Attack(fakeTarget);

        Assert.AreEqual(hero.Experience, fakeTarget.GiveExperience());

    }
}