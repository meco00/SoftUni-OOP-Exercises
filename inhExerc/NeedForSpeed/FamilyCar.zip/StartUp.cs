﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            SportCar sport = new SportCar(200, 200);

            sport.Drive(10);
            
        }
    }
}
