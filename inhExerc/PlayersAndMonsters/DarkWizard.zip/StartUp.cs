﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            DarkKnight newOne = new DarkKnight("alabala", 20);

            System.Console.WriteLine(newOne.ToString());
        }
    }
}